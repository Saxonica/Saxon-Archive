package net.sf.saxon.xpath;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.om.Name;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.ExpressionParser;
import net.sf.saxon.expr.Function;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.functions.XSLTFunction;
import net.sf.saxon.tinytree.TinyBuilder;
import net.sf.saxon.value.*;
import net.sf.saxon.pattern.NameTest;
import net.sf.saxon.pattern.NamespaceTest;
import net.sf.saxon.pattern.LocalNameTest;
import net.sf.saxon.Binding;
import net.sf.saxon.DOMDriver;

import org.w3c.dom.Node;
import org.w3c.dom.Document;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.math.BigDecimal;
import java.util.Date;

import javax.xml.transform.Source;
import javax.xml.transform.TransformerException;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;

/**
  * <p>XPathEvaluator provides a simple API for standalone XPath processing (that is,
  * executing XPath expressions in the absence of an XSLT stylesheet). It is loosely modelled
  * on the proposed org.w3c.dom.xpath.XPathEvaluator interface, though it does not
  * actually implement this interface at present.</p>
  *
  * @author Michael H. Kay (michael.h.kay@ntlworld.com)
  */

 
public class XPathEvaluator {

    private DocumentInfo document = null;
    private NodeInfo contextNode = null;
    private StaticContext staticContext;
    private boolean stripSpace = false;
    
    /**
    * Default constructor. If this constructor is used, a source document must be subsequently
    * supplied using the setSource() method.
    */
    
    public XPathEvaluator() {}
    
    /**
    * Construct an XPathEvaluator to process a particular source document. This is equivalent to
    * using the default constructor and immediately calling setSource().
    * @param source The source document (or a specific node within it).
    */
    
    public XPathEvaluator(Source source) throws XPathException {
        setSource(source);
    }
    
    /**
    * Indicate whether all whitespace text nodes in the source document are to be
    * removed. This option has no effect unless it is called before the call on setSource(),
    * and unless the Source supplied to setSource() is a SAXSource or StreamSource.
    * @param strip True if all whitespace text nodes are to be stripped from the source document,
    * false otherwise. The default if the method is not called is false.
    */
    
    public void setStripSpace(boolean strip) {
        stripSpace = strip;
    }

    /**
    * Supply the document against which XPath expressions are to be executed. This
    * method must be called before preparing or executing an XPath expression. It is possible
    * to supply a different document subsequently; however, prepared XPath expressions are
    * always executed against the document that was current at the time they were prepared.
    * Setting a new source document clears all the namespaces that have been declared.
    * @param source Any javax.xml.transform.Source object representing the document against
    * which XPath expressions will be executed. Note that a Saxon DocumentInfo (indeed any NodeInfo)
    * can be used as a Source. To use a third-party DOM Document as a source, create an instance of 
    * javax.xml.transform.dom.DOMSource to wrap it. Note that this currently creates a copy of the
    * document, and any NodeInfo returned as a result of an expression will be a reference to the
    * copy, not to the original node. The Source object supplied also determines the initial setting
    * of the context item. In most cases the context node will be the root of the supplied document;
    * however, if a NodeInfo is supplied it can be any node in the document.
    * @return the DocumentInfo of the resulting document object.
    */

    public DocumentInfo setSource(Source source) throws XPathException {
        if (source==null) {
            throw new NullPointerException("Source cannot be null");
        }
        if (source instanceof DocumentInfo) {
            document = (DocumentInfo)source;
            contextNode = (NodeInfo)source;
            
        } else if (source instanceof NodeInfo) {
            document = ((NodeInfo)source).getDocumentRoot();
            contextNode = (NodeInfo)source;
            
        } else if (source instanceof SAXSource) {
            try {
                TinyBuilder b = new TinyBuilder();
                b.setNamePool(NamePool.getDefaultNamePool());
                if (stripSpace) {
                    b.setStripAll();
                }       
                document = b.build((SAXSource)source);
                contextNode = document; 
            } catch (TransformerException err) {
                if (err.getException()!=null) {
                    if (err.getException() instanceof XPathException) {
                        throw (XPathException)err.getException();
                    } else if (err.getException() instanceof Exception) {
                        throw new XPathException((Exception)err.getException());
                    } 
                    throw new XPathException(err);
                }
            }           
            
        } else if (source instanceof StreamSource) {
            StreamSource ss = (StreamSource)source;           
            String url = source.getSystemId();
            InputSource is = new InputSource(url);
            is.setCharacterStream(ss.getReader());
            is.setByteStream(ss.getInputStream());
            setSource(new SAXSource(is));

        } else if (source instanceof DOMSource) {
            Node startNode = ((DOMSource)source).getNode();
            if (startNode instanceof NodeInfo) {
                setSource((NodeInfo)startNode);
            } else {
                InputSource is = new InputSource("dummy");
                is.setSystemId(source.getSystemId());
                Document dom;
                if (startNode instanceof Document) {
                    dom = (Document)startNode;
                } else {
                    dom = startNode.getOwnerDocument();
                }
                DOMDriver driver = new DOMDriver();     
                driver.setDocument(dom);                
                driver.setSystemId(source.getSystemId());
                setSource(new SAXSource(driver, is));
            }

        } else {
            throw new IllegalArgumentException("Unknown type of source");
        }
        
        staticContext = new StandaloneContext(document.getNamePool());
        return document;            
        
    }

    
    /**
    * Set the static context for compiling XPath expressions. This provides control over the
    * environment in which the expression is compiled, for example it allows namespace prefixes to
    * be declared, variables to be bound and functions to be defined. For most purposes, the static
    * context can be defined by providing and tailoring an instance of the StandaloneContext class.
    * Until this method is called, a default static context is used, in which no namespaces are defined
    * other than the standard ones (xml, xslt, and saxon), and no variables or functions (other than the
    * core XPath functions) are available.
    */
    
    public void setStaticContext(StaticContext context) {
        staticContext = context;
    }
    
    /**
    * Get the current static context
    */
    
    public StaticContext getStaticContext() {
        return staticContext;
    } 

    /**
    * Prepare an XPath expression for subsequent evaluation. The prepared expression can only
    * be used with the document that has been established using setSource() at the time this method
    * is called.
    * @param expression The XPath expression to be evaluated, supplied as a string.
    * @return an XPathExpression object representing the prepared expression
    * @throws XPathException if the syntax of the expression is wrong, or if it references namespaces,
    * variables, or functions that have not been declared.
    */
    
    public XPathExpression createExpression(String expression) 
    throws XPathException {
        Expression exp = Expression.make(expression, staticContext);
        return new XPathExpression(exp, document);
    }

    /**
    * Set the context node. This provides the context node for any expressions executed after this
    * method is called, including expressions that were prepared before it was called. 
    * @param node The node to be used as the context node. This must
    * be a node within the context document (the document supplied using the setSource() method).
    * @throws NullPointerException if the argument is null
    * @throws IllegalArgumentException if the supplied node is not a node in the context document
    */
    
    public void setContextNode(NodeInfo node) {
        if (node==null) {
            throw new NullPointerException("Context node cannot be null");
        }
        if (document==null) {
            try {
                setSource(node);
            } catch (XPathException err) {
                throw new IllegalStateException("Untrapped error");
            }
        } else if (node.getDocumentRoot() == document) {
            contextNode = node;
        } else {
            throw new IllegalArgumentException("Supplied node is in wrong document");
        }        
    }
    
    /**
    * Prepare and execute an XPath expression, supplied as a string, and returning the results
    * as a List.
    * @param expression The XPath expression to be evaluated, supplied as a string.
    * @return The results of the expression, as a List. The List represents the sequence
    * of items returned by the expression. Each item in the list will either be an instance
    * of net.sf.saxon.om.NodeInfo, representing a node, or a Java object representing an atomic value.
    * The types of Java object that may be included in the list, and the XML Schema data types that they 
    * correspond to, are as follows:<p>
    * <ul>
    * <li>Boolean (xsd:boolean)</li>
    * <li>String (xsd:string)</li>
    * <li>BigDecimal (xsd:decimal)</li>
    * <li>Long (xsd:integer and its derived types)</li>
    * <li>Double (xsd:double)</li>
    * <li>Float (xsd:float)</li>    
    * <li>Date (xsd:dateTime)</li>
    * </ul>    
    */
    
    public List evaluate(String expression) throws XPathException {
        Expression exp = Expression.make(expression, staticContext);
        XPathContext context = new XPathContext(contextNode);
        SequenceIterator iterator = exp.iterate(context);
        ArrayList list = new ArrayList();
        while (iterator.hasNext()) {
            Item item = iterator.next();
            list.add(convert(item));
        }
        return list;        
    }

    /**
    * Internal method to convert an XPath value to a Java object. A node is returned
    * unchanged (as an instance of NodeInfo); an atomic value is returned as an instance
    * of the best available Java class
    */
    
    protected static Object convert(Item item) throws XPathException {
        if (item instanceof NodeInfo) {
            return item;
        } else {
            switch (item.getItemType()) {
                case Type.STRING:
                    return item.getStringValue();
                case Type.BOOLEAN:
                    return new Boolean(((BooleanValue)item).getValue());
                case Type.DECIMAL:
                    return ((DecimalValue)item).getValue();
                case Type.INTEGER:
                    return new Long(((IntegerValue)item).getValue());
                case Type.DOUBLE:
                    return new Double(((DoubleValue)item).getValue());
                case Type.FLOAT:
                    return new Float(((FloatValue)item).getValue());
                case Type.DATE_TIME:
                    return ((DateTimeValue)item).getUTCDate();
                default:
                    throw new XPathException("Unrecognized data type: " + Type.getTypeName(item.getItemType()));
            }
        }
    }
    
    /**
    * Prepare and execute an XPath expression, supplied as a string, and returning the first
    * item in the result. This is useful where it is known that the expression will only return
    * a singleton value (for example, a single node, or a boolean).
    * @param expression The XPath expression to be evaluated, supplied as a string.
    * @return The first item in the sequence returned by the expression. If the expression
    * returns an empty sequence, this method returns null. Otherwise, it returns the first
    * item in the result sequence, represented as a Java object using the same mapping as for
    * the evaluate() method
    */
    
    public Object evaluateSingle(String expression) throws XPathException {
        Expression exp = Expression.make(expression, staticContext);
        XPathContext context = new XPathContext(contextNode);
        SequenceIterator iterator = exp.iterate(context);
        if (iterator.hasNext()) {
            return convert(iterator.next());
        } else {
            return null;
        }                
    }
    


}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/ 
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License. 
//
// The Original Code is: all this file.

// The Initial Developer of the Original Code is
// Michael Kay of Software AG (michael.h.kay@ntlworld.com).
//
// The line marked PB-SYNC is by Peter Bryant (pbryant@bigfoot.com). All Rights Reserved. 
//
// Contributor(s): Michael Kay, Peter Bryant, David Megginson 
//
