package net.sf.saxon.xpath;
import net.sf.saxon.om.DocumentInfo;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.Item;
import net.sf.saxon.om.SequenceIterator;
import net.sf.saxon.expr.Expression;
import net.sf.saxon.expr.XPathContext;
import net.sf.saxon.xpath.XPathException;
import java.util.List;
import java.util.ArrayList;

/**
  * <p>XPathExpression represents a compiled XPath expression that can be repeatedly
  * evaluated.</p>
  *
  *
  *
  * @author Michael H. Kay (michael.h.kay@ntlworld.com)
  */

 
public final class XPathExpression {

    DocumentInfo boundDocument;
    Expression expression;
    NodeInfo contextNode;
    
    /**
    * The constructor is protected, to ensure that instances can only be
    * created using the createExpression() method of XPathEvaluator
    */
    
    protected XPathExpression(Expression exp, DocumentInfo doc) {
        expression = exp;
        boundDocument = doc;
        contextNode = doc;
    }

    /**
    * Set the context node for evaluating the expression. If this method is not called,
    * the context node will be the root of the document to which the prepared expression is
    * bound.
    */
    
    public void setContextNode(NodeInfo node) {
        if (node==null) {
            throw new NullPointerException("Context node cannot be null");
        }
        if (node.getDocumentRoot() == boundDocument) {
            contextNode = node;
        } else {
            throw new IllegalArgumentException("Supplied node is in wrong document");
        }        
    }    

    /**
    * Execute a prepared XPath expression, returning the results as a List.
    * @return The results of the expression, as a List. The List represents the sequence
    * of items returned by the expression. Each item in the list will either be an instance
    * of net.sf.saxon.om.NodeInfo, representing a node, or a Java object representing an atomic value.
    * For the types of Java object that may be returned, see the description of the evaluate method
    * of class XPathProcessor
    */
    
    public List evaluate() throws XPathException {
        XPathContext context = new XPathContext(contextNode);
        SequenceIterator iterator = expression.iterate(context);
        ArrayList list = new ArrayList();
        while (iterator.hasNext()) {
            Item item = iterator.next();
            list.add(XPathEvaluator.convert(item));
        }
        return list;        
    }

    /**
    * Execute a prepared XPath expression, returning the first item in the result. 
    * This is useful where it is known that the expression will only return
    * a singleton value (for example, a single node, or a boolean).
    * @param expression The XPath expression to be evaluated, supplied as a string.
    * @return The first item in the sequence returned by the expression. If the expression
    * returns an empty sequence, this method returns null. Otherwise, it returns the first
    * item in the result sequence, represented as a Java object using the same mapping as for
    * the evaluate() method
    */
    
    public Object evaluateSingle() throws XPathException {
        XPathContext context = new XPathContext(contextNode);
        SequenceIterator iterator = expression.iterate(context);
        if (iterator.hasNext()) {
            return XPathEvaluator.convert(iterator.next());
        } else {
            return null;
        }                
    }    

    /**
    * Get the underlying Saxon expression. This is useful if the expression needs to be
    * passed to internal Saxon interfaces that expect an object of class net.sf.saxon.expr.Expression.
    * It also gives finer control over evaluation of the expression, for example, the ability to
    * iterate over the results.
    * @return the underlying Saxon representation of the expression.
    */
    
    public Expression getExpression() {
        return expression;
    }    

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/ 
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License. 
//
// The Original Code is: all this file.

// The Initial Developer of the Original Code is
// Michael Kay of Software AG (michael.h.kay@ntlworld.com).
//
// The line marked PB-SYNC is by Peter Bryant (pbryant@bigfoot.com). All Rights Reserved. 
//
// Contributor(s): Michael Kay, Peter Bryant, David Megginson 
//
