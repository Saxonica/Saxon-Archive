package net.sf.saxon.xpath;
import net.sf.saxon.Binding;
import net.sf.saxon.expr.StaticContext;
import net.sf.saxon.expr.Function;
import net.sf.saxon.om.NamePool;
import net.sf.saxon.om.NodeInfo;
import net.sf.saxon.om.Namespace;
import net.sf.saxon.om.AxisIterator;
import net.sf.saxon.om.Axis;
import net.sf.saxon.pattern.AnyNodeTest;

import java.util.HashMap;
import java.util.Comparator;

/**
* A StandaloneContext provides a context for parsing an expression or pattern appearing
* in a context other than a stylesheet.
*/

public class StandaloneContext implements StaticContext {

	private NamePool namePool;
	private HashMap namespaces = new HashMap();
	private HashMap collations = new HashMap();
	private Comparator defaultCollation = null;

	/**
	* Create a StandaloneContext using the default NamePool
	*/
	
	public StandaloneContext() {
	    this(NamePool.getDefaultNamePool());
	}

	/**
	* Create a StandaloneContext using a specific NamePool
	*/
	
	public StandaloneContext(NamePool pool) {
		namePool = pool;
		clearNamespaces();
	}
	
	/**
	* Create a StandaloneContext using a specific Node. This node is used to initialize
	* the NamePool and also to establish the initial set of in-scope namespaces
	*/
	
	public StandaloneContext(NodeInfo node) {
	    namePool = node.getDocumentRoot().getNamePool();
	    setNamespaces(node);
	}

	/**
	* Declare a namespace whose prefix can be used in expressions
	*/
	
	public void declareNamespace(String prefix, String uri) {
		namespaces.put(prefix, uri);
		namePool.allocateNamespaceCode(prefix, uri);
	}
	
	/**
	* Clear all the declared namespaces, except for the standard ones (xml, xslt, saxon)
	*/
	
	public void clearNamespaces() {
	    namespaces.clear();
		declareNamespace("xml", Namespace.XML);
		declareNamespace("xsl", Namespace.XSLT);
		declareNamespace("saxon", Namespace.SAXON);
		declareNamespace("", "");
	}
	
	/**
	* Set all the declared namespaces to be the namespaces that are in-scope for a given node.
	* In addition, the standard namespaces (xml, xslt, saxon) are declared.
	* @param node The node whose in-scope namespaces are to be used as the context namespaces.
	* Note that this will have no effect unless this node is an element.
	*/
	
	public void setNamespaces(NodeInfo node) {
	    namespaces.clear();
	    AxisIterator iter = node.getEnumeration(Axis.NAMESPACE, AnyNodeTest.getInstance());
	    while (iter.hasNext()) {
	        NodeInfo ns = (NodeInfo)iter.next();
	        declareNamespace(ns.getLocalName(), ns.getStringValue());
	    }
	}	        

    /**
    * Declare a named collation
    * @param name The name of the collation (technically, a URI)
    * @param comparator The Java Comparator used to implement the collating sequence
    * @param default True if this is to be used as the default collation
    */
    
    public void declareCollation(String name, Comparator comparator, boolean isDefault) {
        collations.put(name, comparator);
        if (isDefault) {
            defaultCollation = comparator;
        }
    } 

    /**
    * Get the NamePool used for compiling expressions
    */
    
    public NamePool getNamePool() {
        return namePool;
    }

    /**
    * Issue a compile-time warning
    */
    
    public void issueWarning(String s) {
        System.err.println(s);
    }

    /**
    * Get the system ID of the container of the expression. Used to construct error messages.
    * @return "" always
    */

    public String getSystemId() {
        return "";
    }

    /**
    * Get the Base URI of the stylesheet element, for resolving any relative URI's used
    * in the expression.
    * Used by the document() function.
    * @return "" always
    */
    
    public String getBaseURI() {
        return "";
    }

    /**
    * Get the line number of the expression within that container.
    * Used to construct error messages.
    * @return -1 always
    */

    public int getLineNumber() {
        return -1;
    }

    /**
    * Get the URI for a prefix, using this Element as the context for namespace resolution
    * @param prefix The prefix
    * @throw XPathException if the prefix is not declared
    */

    public String getURIForPrefix(String prefix) throws XPathException {
    	String uri = (String)namespaces.get(prefix);
    	if (uri==null) {
    		throw new XPathException("Prefix " + prefix + " has not been declared");
    	}
    	return uri;
    }
    
    /**
    * Bind a variable used in this element to the XSLVariable element in which it is declared
    */

    public Binding bindVariable(int fingerprint) throws XPathException {
        throw new XPathException("Variables are not allowed in a standalone expression");
    }

    /**
    * Identify a (namespace-prefixed) function appearing in the expression
    * @throw XPathException if the function is not in scope (note, this doesn't
    * happen in XSLT, where a reference to an unknown function is a dynamic error).
    */
    
    public Function bindFunction(String qname) throws XPathException {
        throw new XPathException("External functions cannot be called in a standalone expression");
    }

    /**
    * Get a named collation.
    * @return the collation identified by the given name, as set previously using declareCollation.
    * Return null if no collation with this name is found.
    */
    
    public Comparator getCollation(String name) {
        return null;     
    }
    
    /**
    * Get the default collation. Return null if no default collation has been defined.
    */
    
    public Comparator getDefaultCollation() {
        return defaultCollation;           
    }

    /**
    * Get the default XPath namespace, as a namespace code that can be looked up in the NamePool
    */
    
    public short getDefaultXPathNamespace() {
        return Namespace.NULL_CODE;
    }

}

//
// The contents of this file are subject to the Mozilla Public License Version 1.0 (the "License");
// you may not use this file except in compliance with the License. You may obtain a copy of the
// License at http://www.mozilla.org/MPL/ 
//
// Software distributed under the License is distributed on an "AS IS" basis,
// WITHOUT WARRANTY OF ANY KIND, either express or implied.
// See the License for the specific language governing rights and limitations under the License. 
//
// The Original Code is: all this file. 
//
// The Initial Developer of the Original Code is
// Michael Kay of International Computers Limited (michael.h.kay@ntlworld.com).
//
// Portions created by (your name) are Copyright (C) (your legal entity). All Rights Reserved. 
//
// Contributor(s): none. 
//
